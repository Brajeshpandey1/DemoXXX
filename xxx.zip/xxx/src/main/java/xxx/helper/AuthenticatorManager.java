package xxx.helper;

public class AuthenticatorManager {
	
	private Boolean isAuthenticated;
	private String authenticatedToken[];
	private String sessionId[];
	
	

	public boolean authenticate(char[] userId,char[] password,char[] authorizationToken)
	{
		boolean isSuccesful=true;
		try{
			//logic for calling the Authorization module
		}
		catch(Exception e)
		{
			
		}
		finally
		{
			this.setAuthenticated(null);
			this.setAuthenticatedToken(null);
			this.setSessionId(null);
			
			
		}
		return isSuccesful;
		
	}
	public AuthenticatorManager()
	{
		
	}
	
	
	public AuthenticatorManager(Boolean isAuthenticated,
			String[] authenticatedToken, String[] sessionId) {
		this.isAuthenticated = isAuthenticated;
		this.authenticatedToken = authenticatedToken;
		this.sessionId = sessionId;
	}



	public Boolean isAuthenticated() {
		return isAuthenticated;
	}
	
	public void setAuthenticated(Boolean isAuthenticated) {
		this.isAuthenticated = isAuthenticated;
	}
	public String[] getAuthenticatedToken() {
		return authenticatedToken;
	}
	public void setAuthenticatedToken(String[] authenticatedToken) {
		this.authenticatedToken = authenticatedToken;
	}
	public String[] getSessionId() {
		return sessionId;
	}
	public void setSessionId(String[] sessionId) {
		this.sessionId = sessionId;
	}

	
}
