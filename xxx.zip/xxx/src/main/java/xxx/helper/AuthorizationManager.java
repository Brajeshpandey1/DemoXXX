package xxx.helper;

public class AuthorizationManager {
		
		private Boolean isAuthorized;
		private String authorizedToken[];
		private String sessionId[];
		
		public AuthorizationManager()
		{
			
		}
		
		
		public AuthorizationManager(boolean isAuthorized,
				String[] authorizedToken, String[] sessionId) {
			super();
			this.isAuthorized = isAuthorized;
			this.authorizedToken = authorizedToken;
			this.sessionId = sessionId;
		}

		public boolean authorize(String userId,String context,char[] authorizationToken)
		{
			boolean isSuccesful=true;
			try{
				//logic for calling the Authorization module
			}
			catch(Exception e)
			{
				
			}
			finally
			{
				this.setAuthorized(null);
				this.setAuthorizedToken(null);
				this.setSessionId(null);
				
				
			}
			return isSuccesful;
			
		}

		public Boolean isAuthorized() {
			return isAuthorized;
		}
		public void setAuthorized(Boolean isAuthorized) {
			this.isAuthorized = isAuthorized;
		}
		public String[] getAuthorizedToken() {
			return authorizedToken;
		}
		public void setAuthorizedToken(String[] authorizedToken) {
			this.authorizedToken = authorizedToken;
		}
		public String[] getSessionId() {
			return sessionId;
		}
		public void setSessionId(String[] sessionId) {
			this.sessionId = sessionId;
		}
		


}
