package xxx.xxx;

import java.util.ArrayList;
import java.util.Iterator;

import javax.servlet.http.HttpServletResponse;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import xxx.helper.AuthenticatorManager;
import xxx.helper.AuthorizationManager;


@RestController
@RequestMapping("/api")
public class ServiceClass {
	/*
		@GetMapping("api")
	public String welcomeUser() {
		return "Hello";
	}*/
	private ArrayList<CustomerRequest> theList;
	private AuthenticatorManager authhenticateMgr = new AuthenticatorManager();
	private AuthorizationManager authorizeManager = new AuthorizationManager();


	public void loadData()
	{
		theList.add(new CustomerRequest(1,"Brajesh","Pandey"));
		theList.add(new CustomerRequest(2,"Ashish", "Garg"));
		theList.add(new CustomerRequest(3,"Rahul","Srinivas"));
		theList.add(new CustomerRequest(4,"Ramyya","Reddy"));

	}
	@RequestMapping(method=RequestMethod.GET,value="/Braj",produces="application/json")
	@ResponseBody
	public CustomerRequest getCusRequest(HttpServletResponse response)
	{
		response.setHeader("userId", "admin");
		response.addHeader("AuthenticationToken", "tokenAthenticated1234567890");
		return new CustomerRequest (1,"Brajesh","PandeyCRM1");

	}
	@RequestMapping(method=RequestMethod.GET,value="/{crmId}/requests/{Id}",produces="application/json")
	@ResponseBody
	public ArrayList<CustomerRequest> getCusRequest1(@PathVariable int Id,@PathVariable String crmId,
			@RequestHeader(value="userId") String userId,@RequestHeader(value="password") String password,
			@RequestHeader(value="AuthenticationToken") String authenticationToken,
			@RequestHeader(value="AuthorizationToken") String authorizationToken,
			HttpServletResponse response){

		theList.add(new CustomerRequest(1,"Brajesh","Pandey"));
		theList.add(new CustomerRequest(2,"Ashish", "Garg"));
		theList.add(new CustomerRequest(3,"Rahul","Srinivas"));
		theList.add(new CustomerRequest(4,"Ramyya","Reddy"));


		ArrayList<CustomerRequest> cr = new ArrayList<CustomerRequest>();
		char[] userIdinput=userId.toCharArray();
		char[] passwordInput=password.toCharArray();
		boolean isAuthenticate;
		boolean isAuthorized;

		isAuthenticate=authhenticateMgr.authenticate(userIdinput, passwordInput,authenticationToken.toCharArray());

		if(isAuthenticate)
		{
			response.setHeader("userId", "admin");
			response.addHeader("AuthenticationToken", "tokenAthenticated1234567890");
			isAuthorized=authorizeManager.authorize(userId, "url:/"+"crmId/requests"+",method:GET",authorizationToken.toCharArray());
		}
		else
		{
			CustomerRequest cr1 =new CustomerRequest();//not authenticated
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			//headers.add("userId",userId.toString() ); 
			cr.add(cr1);
			return cr;
		}

		if(isAuthorized)
		{
			response.addHeader("AuthorizationToken", "tokenAthorize0000000SevenZeroes");
			if(crmId.equals("crm1") && Id<=theList.size()&&!theList.isEmpty())
			{

				cr.add(new CustomerRequest (Id,"Brajesh","PandeyCRM1"));
			}
			else if(crmId.equals("crm2") )
			{
				cr.add(new CustomerRequest (Id,"Brajesh","PandeyCRM2"));
			}
			else
			{
				cr.add(new CustomerRequest ());
			}
		}
		else
		{
			CustomerRequest cr1 =new CustomerRequest();//not authenticated
			response.addHeader("AuthorizationToken", null);
			response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
			cr.add(cr1);
			//return ResponseEntity(cr,hshMap,HttpStatus.FORBIDDEN);
			//not authorized
		}
		return cr;
	}


	@RequestMapping(method = RequestMethod.GET, value="/{crmId}/requests",produces="application/json")
	@ResponseBody
	public ArrayList<CustomerRequest> getRequest(
			@RequestBody ArrayList<CustomerRequest> getReqInp,
			@PathVariable String crmId,
			@RequestHeader(value="userId") String userId,@RequestHeader(value="password") String password,
			@RequestHeader(value="AuthenticationToken") String authenticationToken,
			@RequestHeader(value="AuthorizationToken") String authorizationToken,
			HttpServletResponse response){

		theList.add(new CustomerRequest(1,"Brajesh","Pandey"));
		theList.add(new CustomerRequest(2,"Ashish", "Garg"));
		theList.add(new CustomerRequest(3,"Rahul","Srinivas"));
		theList.add(new CustomerRequest(4,"Ramyya","Reddy"));

		ArrayList<CustomerRequest> custReq = new ArrayList<CustomerRequest>();
		String crmid=crmId;
		char[] userIdinput=userId.toCharArray();
		char[] passwordInput=password.toCharArray();
		boolean isAuthenticate;
		boolean isAutherized;

		isAuthenticate=authhenticateMgr.authenticate(userIdinput, passwordInput,authenticationToken.toCharArray());

		if(isAuthenticate)
		{
			response.setHeader("userId", "admin");
			response.addHeader("Authenticationtoken", "tokenAthenticated1234567890");
			isAutherized=authorizeManager.authorize(userId, "url:/"+"crmId/requests"+",method:GET",authorizationToken.toCharArray());
		}
		else
		{
			CustomerRequest cr1 =new CustomerRequest();//not authenticated
			response.setStatus(HttpServletResponse.SC_FORBIDDEN);
			//headers.add("userId",userId.toString() ); 
			return custReq;

		}

		if(getReqInp.isEmpty()){
			//fetch all
		}
		else
		{
			for(CustomerRequest req:getReqInp)
				custReq.add(theList.get(req.getId()));
		}
		return custReq;

	}

	@RequestMapping(method = RequestMethod.POST, value="/api/{crmId}/requests/register",produces="application/json")
	@ResponseBody
	CustomerRequest registerRequest(@RequestBody CustomerRequest regReqIp,
			@RequestHeader(value="userId") String userId,@RequestHeader(value="password") String password,
			@RequestHeader(value="AuthenticationToken") char[] authenticationToken,
			@RequestHeader(value="AutherizationToken") char[] authorizationToken,
			HttpServletResponse response){

		theList.add(new CustomerRequest(1,"Brajesh","Pandey"));
		theList.add(new CustomerRequest(2,"Ashish", "Garg"));
		theList.add(new CustomerRequest(3,"Rahul","Srinivas"));
		theList.add(new CustomerRequest(4,"Ramyya","Reddy"));

		CustomerRequest custReq = new CustomerRequest();
		custReq.setCrmId(regReqIp.getCrmId());
		custReq.setType(regReqIp.getType());
		custReq.setStatus(regReqIp.getStatus());
		custReq.setId(theList.size()+1);
		theList.add(custReq);
		return custReq;
	}

	@RequestMapping(method = RequestMethod.PUT, value="/api/{CrmIds/requests/register/{Id}",produces="application/json")
	@ResponseBody
	CustomerRequest updateRequest(@RequestBody CustomerRequest regReqIp,
			@PathVariable String crmIds,@PathVariable String Id,
			@RequestHeader(value="userId") String userId,@RequestHeader(value="password") String password,
			@RequestHeader(value="AuthenticationToken") char[] authenticationToken,
			@RequestHeader(value="AutherizationToken") char[] authorizationToken,
			HttpServletResponse response){

		theList.add(new CustomerRequest(1,"Brajesh","Pandey"));
		theList.add(new CustomerRequest(2,"Ashish", "Garg"));
		theList.add(new CustomerRequest(3,"Rahul","Srinivas"));
		theList.add(new CustomerRequest(4,"Ramyya","Reddy"));

		CustomerRequest cusrReq = new CustomerRequest();
		Iterator<CustomerRequest> itr = theList.iterator();
		CustomerRequest cstTemp=new CustomerRequest();
		while(itr.hasNext())
		{
			cstTemp= itr.next();
			if(cstTemp.getId()==regReqIp.getId())
			{
				itr.remove();
				if(crmIds.endsWith("crm1"))
					theList.add(regReqIp);
				else if(crmIds.endsWith("crm1"))
					theList.add(regReqIp);
			}

		}

		/*cusrReq.setCrmId(regReqIp.getCrmId());
		cusrReq.setType(regReqIp.getType());;
		cusrReq.setStatus(regReqIp.getStatus());
		cusrReq.setId(regReqIp.getId());*/
		return cusrReq;
	}


}
